﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlaneController : MonoBehaviour
{
    [SerializeField]
    int totalFans = 3;
    [SerializeField]
    float throwForce = 5;
    [SerializeField]
    float stoppingPower = 2;
    [SerializeField]
    float doubleTapTimelimit = 4f;
    float doubleTapTimer;
    bool tapped = false;
    bool gameStarted = false;

    [SerializeField]
    GameObject ground;
    [SerializeField]
    Camera cam;

    [SerializeField]
    TMP_Text fanUI;
    [SerializeField]
    TMP_Text currentSpeed;
    [SerializeField]
    TMP_Text currentHeight;

    Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotationY;
        rb.constraints = RigidbodyConstraints.FreezeRotationZ;
        rb.AddForce(Vector3.forward * throwForce * 100);
        doubleTapTimer = doubleTapTimelimit;
    }


    private void Update()
    {
        fanUI.text = ("Total Fans: " + totalFans);
        currentSpeed.text = ("Speed: " + (rb.velocity.z).ToString("#.00"));
        currentHeight.text = ("Height: " + (rb.position.y).ToString("#.00"));
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        if (rb.velocity.magnitude > 10)
        {
            gameStarted = true;
        }
        
        // Hold to slow
        if (Input.GetKey(KeyCode.Space))
        {
            rb.AddForce(-Vector3.up);
        }

        // Double tap to boost
        doubleTapTimer += .01f;

        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (totalFans > 0)
            {
                if (tapped)
                {
                    if (doubleTapTimer <= doubleTapTimelimit)
                    {

                        Debug.Log("You have double pressed spacebar!");
                        rb.velocity = new Vector3(rb.velocity.x, 0, rb.velocity.z);
                        rb.AddForce(Vector3.up * 250);
                        totalFans--;
                        tapped = false;
                        doubleTapTimer = 0;
                    }
                }
                else if (tapped == false)
                {
                    
                    tapped = true;
                }
                Debug.Log(Time.time + ": Tapped is " + tapped);
            }
            
            Debug.Log("Current doubleTapTimer time is " + doubleTapTimer);
        }

        if (doubleTapTimer > doubleTapTimelimit)
        {
            doubleTapTimer = 0;
            tapped = false;
        }

        // Add some sort of force that allows the player to get back up from difficult positions
        // If below height 250, you slow down, otherwise, progressively speed up.
        rb.AddForce(Vector3.forward * Mathf.Clamp((transform.position.y - 250) / 200, 0, 5));

        if (rb.velocity.magnitude <= 1 && gameStarted || transform.position.y <= ground.transform.position.y + 2 && gameStarted)
        {
            GameOver();
        }

        rb.transform.rotation = Quaternion.Euler(Mathf.Clamp(-rb.velocity.y, -90, 15), 0, 0);
        cam.transform.position = new Vector3(200, transform.position.y, transform.position.z);
    }

    private void OnCollisionEnter(Collision collision)
    {
        rb.AddForce(-Vector3.forward * stoppingPower);
    }

    void GameOver()
    {
        rb.velocity = Vector3.zero;
        rb.constraints = RigidbodyConstraints.FreezeAll;
        Debug.Log("Game Over!");
    }
}
